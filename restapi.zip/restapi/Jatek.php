<?php
$conn = mysqli_connect("localhost","root","","jateklista");
class Jatek{
    function Osszes()
    {
        global $conn;
        $sql = "SELECT * FROM jatekok";
        $result = $conn->query($sql);
        return $result->fetch_all(MYSQLI_ASSOC);
    }
    function Egyik($id)
    {
        global $conn;
        $sql = "SELECT * FROM jatekok WHERE id='$id'";
        $result = $conn->query($sql);
        return $result->fetch_all(MYSQLI_ASSOC);
    }
    function Sorrend($sorrend)
    {
        global $conn;
        $sql = "SELECT * FROM jatekok ORDER BY $sorrend";
        $result = $conn->query($sql);
        return $result->fetch_all(MYSQLI_ASSOC);
    }
}
?>