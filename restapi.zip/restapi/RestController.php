<?php
include("JatekRestHandler.php");
header('Content-Type: application/json; charset=utf-8');
if (isset($_GET["jatek"])) {
    if ($_GET["jatek"] == 'osszes') {
        $jatek = new JatekRestHandler();
        $jatek->OsszesJatek();
    }
    elseif ($_GET["jatek"] == 'egyik') {
        $jatek = new JatekRestHandler();
        $jatek->EgyikJatek($_GET["id"]);
    }
    elseif ($_GET["jatek"] == 'sorrend') {
        $jatek = new JatekRestHandler();
        $jatek->JatekokSorrendben($_GET["sorrend"]);
    }
}
?>