<?php
require_once("Jatek.php");
class JatekRestHandler {

	
	public function EncodeJson($responseData) {
		return json_encode($responseData);	
	}
	function OsszesJatek() {	

		$jatek = new Jatek();
		$rawData = $jatek->Osszes();

		if(empty($rawData)) {
			$statusCode = 404;
			$rawData = array('error' => 'a kiolvasas nem sikerult');		
		} else {
			$statusCode = 200;
		}

		echo $this->EncodeJson($rawData);
	}
	public function EgyikJatek($id) {

		$jatek = new Jatek();
		$rawData = $jatek->Egyik($id);

		if(empty($rawData)) {
			$statusCode = 404;
			$rawData = array('error' => 'A játék nem található');		
		} else {
			$statusCode = 200;
		}
				
		echo $this->EncodeJson($rawData);
	}
    public function JatekokSorrendben($sorrend) {

		$jatek = new Jatek();
		$rawData = $jatek->Sorrend($sorrend);

		if(empty($rawData)) {
			$statusCode = 404;
			$rawData = array('error' => 'A megadott nevű sorrend nem megfelelő');
		} else {
			$statusCode = 200;
		}
				
		echo $this->EncodeJson($rawData);
	}
}
?>