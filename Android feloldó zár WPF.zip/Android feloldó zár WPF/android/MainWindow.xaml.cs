﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace android
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        string jelszo = "";

        private void EgerMozog(object sender, MouseEventArgs e)
        {
            Label akt = e.Source as Label;

            if (akt != null && e.LeftButton == MouseButtonState.Pressed && !jelszo.Contains(akt.Content.ToString()))
            {
                jelszo += akt.Content.ToString();
                akt.Background = Brushes.Yellow;
            }
        }

        private void EgerFelEnged(object sender, MouseButtonEventArgs e)
        {
            if (jelszo != string.Empty)
            {
                MessageBox.Show(jelszo);
                jelszo = string.Empty;

                foreach (UIElement elem in Grid.Children)
                {
                    if (elem is Label)
                    {
                        (elem as Label).Background = Brushes.Red;
                    }
                }
            }
        }
    }
}
